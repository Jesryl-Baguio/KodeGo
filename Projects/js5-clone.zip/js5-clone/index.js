const express = require('express');
const app = express();
const path = require('path');
const methodOverride = require('method-override');
const port = 8080;
let data = require('./data.json');
const { v4:uuid } = require('uuid');

//! Middleware
app.use(methodOverride('_method'))
app.use(express.urlencoded({extended:true}))
app.use(express.json());
app.set('view engine', 'ejs')
app.set('views', path.join(__dirname, 'views'))

app.use(express.static(path.join(__dirname, "node_modules/bootstrap/dist/")))



//! Home page route
app.get('/home', (req, res) => {
  res.render('products/home')
})


//! Product page route
app.get('/products', (req, res) => {
  res.render('products/products', { product:data });
});

//! Details Route by ID
app.get('/products/:id', (req, res) => {
  const { id } = req.params;
  const productData = data.find(c => c.id === id);
  res.render('products/details', { productData })
})


// ! Add item route
app.post('/products', (req, res) => {
  const { brand, product, img} = req.body;
  data.push({brand, product, img, id: uuid()})
  res.redirect('products')
})

//! Update Item
app.patch('/products/:id', (req, res) => {
  const { id } = req.params;
  const updatedProduct = data.find(prod => prod.id === id);

  if (updatedProduct) {
      updatedProduct.brand = req.body.brand;
      updatedProduct.product = req.body.product;
      updatedProduct.img = req.body.img;
      res.redirect('/products');
  } else {
      res.status(404).send('Item not found');
  }
});

//! Delete Item
app.delete('/products/:id', (req, res) => {
  const { id } = req.params;
  data = data.filter(c => c.id !== id);
  res.redirect('/products');
})


// ! Port
app.listen(port, () => console.log(`Server is running on Port:${port}`))
