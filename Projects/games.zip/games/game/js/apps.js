
alert("Welcome to Pizza Delight!");

//variable command
const bill =  parseFloat(prompt("What size pizza do you want? (SMALL, MEDIUM, or LARGE)?")) ; // Total bill - P6,250.00
const split = parseInt(prompt("Do you want pepperoni? (YES or NO)?")) ; // Split each person - 5
const tip = parseFloat(prompt("Do you want extra cheese? (YES or NO)")); // Tip each person - 10%


// computation
const tipPercentage = tip / 100  // 10% divided by 100 = 0.10
const billAmnt = bill * tipPercentage  // 6250 multiply by  0.10(10%) = 625
const totalBill = billAmnt + bill  // 625 + 6250 = 6,875


// display output
document.getElementById("bill").innerHTML = ` ${bill}`;
document.getElementById("split").innerHTML =`${split}`;
document.getElementById("tip").innerHTML = `${tip}`;
document.getElementById("totalBill").innerHTML = `$ ${ (totalBill / split).toFixed(2)}`; // Bill Amount / split(5 person) = 1,375 total bill each person


// alert("Welcome to Pizza Delight!");

// let pizzaSize = prompt("Choose pizza size:(S, M, or L)");

// let pepperoni = prompt("Do you want pepperoni? (Y or N)");

// let extraCheese = prompt("Do you want extra cheese? (Y or N)");

// let total = 0;

// if (pizzaSize === "S") {
//   total = 15;
// } else if (pizzaSize === "M") {
//   total = 20;
// } else if (pizzaSize === "L") {
//   total = 25;
// } else {
//   console.log("Invalid pizza size.");
// }

// if (pepperoni === "Y") {
//   total += 2;
// }

// if (extraCheese === "Y") {
//   total += 1;
// }

// console.log("Your final bill is: $" + total);