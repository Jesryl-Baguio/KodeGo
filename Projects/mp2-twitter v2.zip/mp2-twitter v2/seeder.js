const mongoose = require('mongoose');

// mongoose.connect('mongodb+srv://jesrylbaguio:Jb.1234567@cluster0.rqpztnr.mongodb.net/LoginSignup')
mongoose.connect('mongodb://localhost:27017/twitter')
  .then(() => {
    console.log('Mongodb connected');
  })
  .catch(() => {
    console.log('failed to connect');
  });

const logInSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  }
});

const Credentials = mongoose.model('Credentials', logInSchema);

module.exports = Credentials;