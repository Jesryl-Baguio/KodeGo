const express = require('express');
const app = express();
const path = require('path');
const methodOverride = require('method-override')
const port = 8090;
let Credentials = require('./seeder')

//! Middleware 
app.use(methodOverride('_method'))
app.use(express.urlencoded({extended:true}))
app.use(express.static("public"))
app.use(express.json());



app.set('view engine', 'ejs')
app.set('views', path.join(__dirname, 'views'));



// ROUTES!

app.get('/home', (req, res) => {
  res.render('home')
})

app.get('/login', (req, res) => res.render('login'));

// Login form submission route
app.post('/perform_login', async (req, res) => {
  try {
    const user = await Credentials.findOne({ email: req.body.email });
    if (user && user.password === req.body.password) {
      res.redirect('/home'); // Redirect to home page
    } else {
      res.render('login', { error: "Incorrect email or password" });
    }
  } catch (error) {
    res.render('login', { error: "An error occurred during login" });
  }
});



// Signup form submission route
app.post('/perform_signup', async (req, res) => {
  try {
    const newUser = new Credentials(req.body);
    await newUser.save();
    res.redirect('/login'); // Redirect to login page after signup
  } catch (error) {
    res.render('login', { error: "An error occurred during signup" });
  }
});




//! Port
app.listen(port, () => console.log(`Server is running on Port:${port}`))
 

